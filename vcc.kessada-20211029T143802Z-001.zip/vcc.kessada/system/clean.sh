#!/bin/bash

rm images/*.png

rm log/*.xml

rm output/*.xml
rm output/*.txt

rm summary/*.xml

rm src/*.pyc

rm *.png

rm -rf src/__pycache__

echo "OK!"
